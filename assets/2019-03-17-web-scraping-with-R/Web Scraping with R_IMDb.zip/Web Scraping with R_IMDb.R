library('rvest')
library('ggplot2')
library('mice')

url <- 'https://www.imdb.com/search/title?count=100&release_date=2018-01-01,2018-12-31&view=advanced'
webpage <- read_html(url)

##### Rank
rank_data_html <- html_nodes(webpage, '.text-primary')
rank_data <- html_text(rank_data_html)
rank_data <- as.numeric(rank_data)

##### Title
title_data_html <- html_nodes(webpage, '.lister-item-header a')
title_data <- html_text(title_data_html)

##### Description
description_data_html <- html_nodes(webpage, '.ratings-bar+ .text-muted')
description_data <- html_text(description_data_html)
description_data <- gsub('\n', '', description_data)

##### Runtime
runtime_data_html <- html_nodes(webpage, '.runtime')
runtime_data <- html_text(runtime_data_html)
runtime_data <- gsub('min', '', runtime_data)
runtime_data <- as.numeric(runtime_data)

##### Genre
genre_data_html <- html_nodes(webpage, '.genre')
genre_data <- html_text(genre_data_html)
genre_data <- gsub('\n', '', genre_data)
genre_data <- gsub(' ', '', genre_data)

##### Rating
rating_data_html <- html_nodes(webpage, '.ratings-imdb-rating strong')
rating_data <- html_text(rating_data_html)
rating_data <- as.numeric(rating_data)

##### Metascore
metascore_data_html <- html_node(html_nodes(webpage, '.lister-item-content'), '.metascore')
metascore_data <- html_text(metascore_data_html)
metascore_data <- as.numeric(metascore_data)

##### Votes
votes_data_html <- html_nodes(webpage, '.sort-num_votes-visible span:nth-child(2)')
votes_data <- html_text(votes_data_html)
votes_data <- gsub(',', '', votes_data)
votes_data <- as.numeric(votes_data)

##### Gross
gross_data_html <- html_node(html_nodes(webpage, '.lister-item-content'), '.sort-num_votes-visible span:nth-child(5)')
gross_data <- html_text(gross_data_html)
gross_data <- gsub('M', '', gross_data)
gross_data <- substring(gross_data, 2, 6)
gross_data <- as.numeric(gross_data)

##### Movies DataFrame
movies <- data.frame(
  rank = rank_data,
  title = title_data,
  description = description_data,
  runtime = runtime_data,
  genre = genre_data,
  rating = rating_data,
  metascorre = metascore_data,
  votes = votes_data,
  gross = gross_data
)


##### Output
write.csv(movies, file = file.choose(new = TRUE), row.names = FALSE)







