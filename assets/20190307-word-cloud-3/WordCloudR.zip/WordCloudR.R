# Install
install.packages("tm")  # for text mining
install.packages("wordcloud") # word-cloud generator 
install.packages("RColorBrewer") # color palettes

# Load
library("tm")
library("wordcloud")
library("RColorBrewer")

#Read text file
text <- readLines(file.choose())
# Load the data as a corpus
docs <- Corpus(VectorSource(text))
#Inspect the content
inspect(docs)[1:10]
# Convert the text to lower case
docs <- tm_map(docs, content_transformer(tolower))
# Remove numbers
docs <- tm_map(docs, removeNumbers)
# Remove english common stopwords
docs <- tm_map(docs, removeWords, stopwords("english"))
# Remove punctuations
docs <- tm_map(docs, removePunctuation)
# Eliminate extra white spaces
docs <- tm_map(docs, stripWhitespace)
#Creates a TDM
dtm <- TermDocumentMatrix(docs)
#Convert this into a matrix format
m <- as.matrix(dtm)
#Gives you the frequencies for every word
v <- sort(rowSums(m),decreasing=TRUE)
d <- data.frame(word = names(v),freq=v)
#Scan the data
head(d, 10)
#Plot Word Cloud
wordcloud(words = d$word, freq = d$freq, scale=c(5,0.5), min.freq = 1,
          max.words=200, random.order=FALSE, rot.per=0.35, 
          colors=brewer.pal(8, "Accent"))
