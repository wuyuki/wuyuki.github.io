%read txt as a string
text = string(fileread('C:\Users\originlab\Desktop\WordCloudHistory.txt'));
%delete puchuation
punctuationCharacters = ["." "?" "!" "," ";" ":"];
text = replace(text,punctuationCharacters," ");
%convert a string to array
words = split(join(text));
%delete the words has less than 5 characters, which are problely stop words
words(strlength(words)<5) = [];
%change all words to lowercase
words = lower(words);
%calculate the frequencies for every word
[numOccurrences,uniqueWords] = histcounts(categorical(words));
figure
%set properties for word cloud
wordcloud(uniqueWords,numOccurrences,'Shape', "rectangle", 'MaxDisplayWords', 200);
title("Word Cloud History")