#load packages
library(ggplot2) #graphing
library(ggthemes) #graphing
library(ggmosaic) #graphing
library(scales) #graphing
library(dplyr) #data manipulation
library(mice) #text data manipulation
library(randomForest)


######### 1. Load and Check Data #########
# choose data file
trainFile <- file.choose()
testFile <- file.choose()

# read file
train <- read.csv(trainFile, stringsAsFactors = FALSE)
test <- read.csv(testFile, stringsAsFactors = FALSE)
full <- bind_rows(train, test)
str(full)

# prepare data
full$Survived <- as.logical(full$Survived)
factor_vars <- c('Pclass', 'Sex', 'Embarked')
full[factor_vars] <- lapply(full[factor_vars], factor)


######### 2. Feature Engineering 1 #########

# age, pclass, sex vs. survived
plot1 <- ggplot(full[1:891,]) + 
          geom_jitter(aes(x=Age, y=Pclass, color=Survived), position = position_jitter(height = .1)) +
          facet_grid(rows=vars(Sex)) +
          scale_color_discrete(labels = c('Not Survived', 'Survived'))
print(plot1)


# extract title from names
full$Title <- gsub('(.*, )|(\\..*)', '', full$Name)
table(full$Title, full$Sex)
rare_title <- c('Capt', 'Col', 'Don', "Dona", 'Dr', 'Jonkheer', 'Major', 'Rev', 'the Countess')
full$Title[full$Title == 'Mlle'] <- 'Miss'
full$Title[full$Title == 'Ms'] <- 'Miss'
full$Title[full$Title == 'Lady'] <- 'Miss'
full$Title[full$Title == 'Mme'] <- 'Mrs'
full$Title[full$Title == 'Sir'] <- 'Mr'
full$Title[full$Title %in% rare_title] <- 'Rare Titles'
table(full$Title, full$Sex)

# title vs. survived
plot2 <- ggplot(full[1:891,]) +
  geom_bar(aes(x=Title, fill=Survived), stat='count', position = 'dodge') +
  scale_fill_discrete(labels = c('Not Survived', 'Survived')) +
  labs(x='Title', y='Count', fill='Survived')
print(plot2)

# create family size
full$FamilySize <- full$SibSp + full$Parch + 1;
# modify family size
full$FamilySizeAdj <- full$FamilySize
cabin <- data.frame(table(Var1 = full$Cabin))
cabin <- subset(cabin, nchar(as.character(Var1)) > 1)
cabin <- subset(cabin, cabin$Freq > 1)
full$FamilySizeAdj[full$FamilySize ==1 & full$Cabin %in% cabin$Var1] <- 2

# family size vs. survival
plot3 <- ggplot(full[1:891,]) +
          geom_histogram(aes(x=FamilySize, fill=Survived), stat='bin', position = 'dodge', binwidth = 0.5) +
          scale_x_continuous(breaks = c(1:11)) +
          scale_fill_discrete(labels = c('Not Survived', 'Survived')) +
          labs(x='Family Size', y='Count', fill='Survived')
print(plot3)

# discretize family size
full$FamilySizeD[full$FamilySize == 1] <- 'single'
full$FamilySizeD[full$FamilySize > 1 & full$FamilySize < 5] <- 'small'
full$FamilySizeD[full$FamilySize > 4] <- 'large'

# plot mosaic plot for family size vs. Survival
plot4 <- ggplot(full[1:891,]) +
          geom_mosaic(aes(x=product(FamilySizeD), fill=Survived)) + 
          scale_y_productlist(labels = c('Not Survived', 'Survived')) + 
          scale_fill_discrete(labels = c('Not Survived', 'Survived')) + 
          labs(x='Family Size', y='', fill='Survived') 
print(plot4)

# extract surname from names
#full$Surname <- sapply(full$Name, function(x) strsplit(x, split = '[,.]')[[1]][1])
# create family record
#full$Family <- paste(full$Surname, full$FamilySizeAdj, sep='_')


######### 3. Handle Missing Value #########
# count missing value per column
sapply(full, function(x) sum(is.na(x)|x == ''))


# handle the missing values in col(Embarked)
embarked_missing <- full %>% filter(Embarked == '')
# plot box plot for fare vs. embarked port
plot5 <- ggplot(full, aes(x = Embarked, y = Fare, fill = Pclass)) +
          geom_boxplot() +
          geom_hline(aes(yintercept=80), colour='darkred', linetype='dashed', lwd=2) +
          scale_x_discrete(limits=c('C', 'Q', 'S')) + 
          scale_y_continuous(labels=dollar_format())
print(plot5)
# from the plot we could infer that these people might embarked at C port (1st class $80)
full$Embarked[c(62, 830)] <- 'C'
# pclass, embarked vs. survived
plot6 <- ggplot(full[1:891,]) + 
          #geom_boxplot(aes(x=Pclass, y=Fare, color=Survived)) +
          geom_bar(aes(x=Pclass, fill=Survived), stat='count', position = 'dodge') +
          facet_grid(cols=vars(Embarked)) +
          scale_fill_discrete(labels = c('Not Survived', 'Survived')) +
          labs(x='Pclass', y='Count', fill='Survived')
print(plot6)


# handle the missing values in col(Fare)
fare_missing <- full %>% filter(Fare == '' | is.na(Fare))
# plot box plot for fare vs. embarked port
plot7 <- ggplot(full[full$Pclass == 3 & full$Embarked == 'S', ], aes(x = Fare)) +
          geom_density(alpha = 0.4) +
          geom_vline(aes(xintercept=median(Fare, na.rm = TRUE)), colour='darkred', linetype='dashed', lwd=2) +
          scale_y_continuous(labels=dollar_format())
print(plot7)
# from the plot we could replace the missing value by median value of 3rd class & embared = S port
full$Fare[1044] <- median(full[full$Pclass == 3 & full$Embarked == 'S', ]$Fare, na.rm = TRUE)
# fare vs. survived
plot8 <- ggplot(full[1:891,]) + 
          geom_boxplot(aes(y=Fare, fill=Survived)) +
          scale_fill_discrete(labels = c('Not Survived', 'Survived')) +
          labs(y='Count', fill='Survived') +
          theme(axis.title.x.bottom = element_blank(), 
                axis.text.x.bottom = element_blank(), 
                axis.ticks.x.bottom = element_blank())
print(plot8)


# handle the missing values in col(Age)
factor_vars <- c('Title','FamilySizeD')
full[factor_vars] <- lapply(full[factor_vars], factor)
# set a random seed
set.seed(129)
mice_mod <- mice(full[, !names(full) %in% c('PassengerId','Name', 'Sex','Fare','Title', 'Embarked', 'FamilySizeAdj', 'FamilySizeD', 'Survived')], method='rf') 
mice_output <- complete(mice_mod)
# original data
plot9_1 <- ggplot(full, aes(x=Age)) +
            geom_histogram(stat='bin', na.rm=TRUE, fill='#F8766D') 
print(plot9_1)
# new data
plot9_2 <- ggplot(mice_output, aes(x=Age)) +
            geom_histogram(stat='bin', fill='#00BFC4')
print(plot9_2)
# replace age
full$Age <- mice_output$Age
# count missing value per column
sapply(full, function(x) sum(is.na(x)|x == ''))
# check missing value patter
md.pattern(full, rotate.names = TRUE)


######### 4. Feature Engineering 2 #########
plot10 <- ggplot(full[1:891,], aes(x=Age, fill=Survived)) +
          geom_histogram(stat='bin') + 
          facet_grid(rows=vars(Sex)) + 
          scale_fill_discrete(labels = c('Not Survived', 'Survived')) + 
          labs(x='Age', y='Count', fill='Survived')
print(plot10)
# extract IsChild
full$IsChild[full$Age >= 18] <- 0
full$IsChild[full$Age < 18] <- 1
# extract IsMother
full$IsMother <- 0
full$IsMother[full$Sex == 'female' & full$Parch > 0 & full$Age > 18 & full$Title != 'Miss'] <- 1
# convert variables into factor
full$IsChild <- as.logical(full$IsChild)
full$IsMother <- as.logical(full$IsMother)
# ischild vs. survived
plot11 <- ggplot(full[1:891,]) + 
            geom_bar(aes(x=IsChild, fill=Survived), stat='count', position = 'dodge') +
            scale_fill_discrete(labels = c('Not Survived', 'Survived')) +
            scale_x_discrete(labels = c('Not Child', 'Child')) +
            labs(y='Count', fill='Survived')
print(plot11)
# ismother vs. survived
plot12 <- ggplot(full[1:891,]) + 
  geom_bar(aes(x=IsMother, fill=Survived), stat='count', position = 'dodge') +
  scale_fill_discrete(labels = c('Not Survived', 'Survived')) +
  scale_x_discrete(labels = c('Not Mother', 'Mother')) +
  labs(y='Count', fill='Survived')
print(plot12)


######### 5. Prediction #########
# split data set
train <- full[1:891,]
test <- full[892:1309,]
# building model using random forest
set.seed(891)
rf_model <- randomForest(factor(Survived) ~ Pclass + Sex + Fare + Embarked + Title + FamilySizeAdj, data = train)
plot13 <- plot(rf_model)
legend('topright', colnames(rf_model$err.rate), col=1:3, fill=1:3)
print(plot13)
# variable importance
rf_importance <- importance(rf_model)
varImportance <- data.frame(Variables = row.names(rf_importance), Importance = rf_importance[,'MeanDecreaseGini'])
rankImportance <- varImportance %>% mutate(Rank = paste0('#', dense_rank(desc(Importance))))
plot14 <-  ggplot(rankImportance, aes(x= reorder(Variables, Importance), y=Importance, fill = Importance)) +
            geom_bar(stat='identity') +
            geom_text(aes(x = Variables, y = 5, label = Rank), size = 4, color='yellow') +
            labs(x = 'Variables') +
            coord_flip()
print(plot14)
# predict using test data
prediction <- predict(rf_model, test)
# save result
predition_result <- data.frame(PassengerID = test$PassengerId, Survived = prediction)
predition_result$Survived <- as.integer(as.logical(predition_result$Survived))
# output cvs file
write.csv(predition_result, file = file.choose(new = TRUE), row.names = FALSE)

