"""
Python Example
===============
Generating a wordcloud from the txt file using Python.
"""

from wordcloud import WordCloud

# Read the whole text from txt.
fp = "C:/Users/yuki/Desktop/WordCloudHistory.txt"
text = open(fp).read()

# Generate a word cloud image
wordcloud = WordCloud(
font_path = "C:/Windows/Fonts/BROADW.TTF", 
width = 600, #width of the canvas.
height = 400, #height of the canvas.
max_font_size = 60,
font_step = 1,
background_color = "white",
random_state = 1,
margin = 2,
colormap = "tab20" #matplotlib colormap
).generate(text)

# Display the generated image in matplotlib way:
import matplotlib.pyplot as plt
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()

