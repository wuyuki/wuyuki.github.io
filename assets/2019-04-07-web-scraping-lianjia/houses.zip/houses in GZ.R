library("rvest")

url <- "https://gz.lianjia.com/ershoufang/pg"
houseInfo <- data.frame()
for (ii in 1:1553){
  houseInfo <- rbind(houseInfo, getHouseInfo(ii, url))
}
id <- c(1:length(houseInfo$title))
houseInfo <- cbind(id, houseInfo)
#might need to pick a proper encoding method according to your OS
write.csv(houseInfo, file = file.choose(new = TRUE), row.names = FALSE)

getHouseInfo <- function(pageNum, urlWithoutPageNum) {
  
url <- paste0(urlWithoutPageNum, pageNum)
webpage <- read_html(url,encoding="UTF-8")

title_data_html <- html_node(html_nodes(webpage, '.LOGCLICKDATA'), "div[class='title'] a") 
title_data <- html_text(title_data_html)

block_data_html <- html_nodes(webpage, "div[class='houseInfo'] a")
block_data <- html_text(block_data_html)

house_info_data_html <- html_nodes(webpage, "div[class='houseInfo']")
house_info_data <- html_text(house_info_data_html)
room_num_data <- sapply(house_info_data, function(x) strsplit(x, split = " | ", fixed=TRUE)[[1]][2])
house_area_data <- sapply(house_info_data, function(x) strsplit(x, split = " | ", fixed=TRUE)[[1]][3])
house_orientation_data <- sapply(house_info_data, function(x) strsplit(x, split = " | ", fixed=TRUE)[[1]][4])
house_decoration_data <- sapply(house_info_data, function(x) strsplit(x, split = " | ", fixed=TRUE)[[1]][5])
elevator_data <- sapply(house_info_data, function(x) strsplit(x, split = " | ", fixed=TRUE)[[1]][6])

room_num_data <- gsub("(室)|(厅)", "|", room_num_data)
livingroom_num_data <- as.numeric(sapply(room_num_data, function(x) strsplit(x, split = "|", fixed=TRUE)[[1]][2]))
room_num_data <- as.numeric(sapply(room_num_data, function(x) strsplit(x, split = "|", fixed=TRUE)[[1]][1]))
house_area_data <- as.numeric(gsub("平米", "", house_area_data))
house_orientation_data <- sapply(house_orientation_data, function(x) strsplit(x, split = " ", fixed=TRUE)[[1]][1])
house_decoration_data <- as.factor(house_decoration_data)
elevator_data <- gsub("电梯", "", elevator_data)
elevator_data[elevator_data == "有"] <- 1
elevator_data[elevator_data == "无"] <- 0
elevator_data <- as.logical(as.numeric(elevator_data))

position_info_data_html <- html_nodes(webpage, "div[class='positionInfo']")
position_info_data <- html_text(position_info_data_html)
level_data <- as.factor(sapply(position_info_data, function(x) substring(x, 1, 1)))
total_level_data <- sapply(position_info_data, function(x) strsplit(x, split = "层", fixed=TRUE)[[1]][2])
total_level_data <- as.numeric(gsub("\\(共", "", total_level_data))
year_data <- sapply(position_info_data, function(x){
              if(grepl("年", x, fixed = TRUE)) {
                temp <- strsplit(x, split = "年", fixed=TRUE)[[1]][1]
                substr(temp, nchar(temp)-3, nchar(temp))
              }
              else {
                NA
              }
            })
build_data <- sapply(position_info_data, function(x){
              if(grepl("楼  -  ", x, fixed = TRUE)) {
                temp <- strsplit(x, split = "  -  ", fixed=TRUE)[[1]][1]
                substr(temp, nchar(temp)-1, nchar(temp))
              }
              else {
                NA
              }
            })
build_data <- as.factor(build_data)
district_data_html <- html_nodes(webpage, "div[class='positionInfo'] a")
district_data <- html_text(district_data_html)

follow_info_data_html <- html_nodes(webpage, "div[class='followInfo']")
follow_info_data <- html_text(follow_info_data_html)
follow_data <- sapply(follow_info_data, function(x) strsplit(x, split = " / ", fixed=TRUE)[[1]][1])
follow_data <- as.numeric(gsub("人关注", "", follow_data))
check_data <- sapply(follow_info_data, function(x) strsplit(x, split = " / ", fixed=TRUE)[[1]][2])
check_data <- as.numeric(gsub("(次带看)|(共)", "", check_data))
time_data <- sapply(follow_info_data, function(x) strsplit(x, split = " / ", fixed=TRUE)[[1]][3])
time_data <- gsub("以前发布", "", time_data)
time_data <- sapply(time_data,  function(x) {
                        if("月" == substr(x, nchar(x), nchar(x))) {
                          as.numeric(gsub("个月", "", x))*30
                        }
                        else {
                          as.numeric(gsub("天", "", x))
                        }
  })

tax_free_data_html <- html_node(html_nodes(webpage, '.LOGCLICKDATA'), "span[class='taxfree']")
tax_free_data <- html_text(tax_free_data_html)

total_price_data_html <- html_nodes(webpage, "div[class='totalPrice']")
total_price_data <- as.numeric(gsub("万", "", html_text(total_price_data_html)))
unit_price_data_html <- html_nodes(webpage, "div[class='unitPrice']")
unit_price_data <- as.numeric(gsub("(单价)|(元/平米)", "", html_text(unit_price_data_html)))

house <- data.frame(
  title = title_data,
  block = block_data,
  room = room_num_data,
  livingroom = livingroom_num_data,
  area = house_area_data,
  orientation = house_orientation_data,
  decoration = house_decoration_data,
  elevator = elevator_data,
  level = level_data,
  total_level = total_level_data,
  building_year = year_data,
  building = build_data,
  district = district_data,
  follow = follow_data,
  check = check_data,
  release_time = time_data,
  tax_free = tax_free_data,
  total_price = total_price_data,
  unit_price = unit_price_data
)
return (house)
}

